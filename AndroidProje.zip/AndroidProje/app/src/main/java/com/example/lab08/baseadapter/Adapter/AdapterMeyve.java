package com.example.lab08.baseadapter.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.baseadapter.Model.Meyve;
import com.example.lab08.baseadapter.R;

import java.util.ArrayList;

public class AdapterMeyve extends BaseAdapter{

private ArrayList<Meyve> meyveler;
private Context context;
private LayoutInflater layoutInflater;
//her bir satırın ilgili layouta bağlanması işlemini gerçekleştirir

    public AdapterMeyve() {
    }
    public AdapterMeyve(ArrayList<Meyve> meyveler,Context context){

        this.context=context;
        this.meyveler=meyveler;
        this.layoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return meyveler.size();
        //listenin eleman sayısı
    }

    @Override
    public Meyve getItem(int position) {//listenin i'ninci sıradaki elemanını döner
        return meyveler.get(position);
    }

    @Override
    public long getItemId(int position) {//her liste elemanın kaçıncı sırada olduğunu döner
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {//her bir liste elemanının satır görüntüsünü döner
        //position kaçıncı sırada olduğumu döner
        //idenx=position

        View v=layoutInflater.inflate(R.layout.meyve_satirgoruntusu,null);

        ImageView image=v.findViewById(R.id.image);
        TextView TextView=v.findViewById(R.id.TextView);

        TextView.setText(meyveler.get(position).getAd());
        image.setImageResource(meyveler.get(position).getResim());


        return v;
    }
}
