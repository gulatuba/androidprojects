package com.example.lab08.baseadapter.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.lab08.baseadapter.Adapter.AdapterMeyve;
import com.example.lab08.baseadapter.Model.Meyve;
import com.example.lab08.baseadapter.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Meyve> meyveler=new ArrayList<>();
    AdapterMeyve adapterMeyve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=findViewById(R.id.list_view);
        meyveler.add(new Meyve("Elma",R.drawable.elma));
        meyveler.add(new Meyve("Karpuz",R.drawable.karpuz));
        meyveler.add(new Meyve("Üzüm",R.drawable.uzun));


        adapterMeyve=new AdapterMeyve(meyveler,getApplicationContext());
        listView.setAdapter(adapterMeyve);
    }
}
