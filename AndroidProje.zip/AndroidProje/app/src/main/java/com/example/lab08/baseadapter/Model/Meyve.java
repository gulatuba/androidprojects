package com.example.lab08.baseadapter.Model;

public class Meyve {
    //iki tane field üretimi yaptık

    private String ad;
    private int resim;

    //kapsülleme işlemi

    public Meyve(String ad, int resim) {
        this.ad = ad;

        this.resim = resim;
    }

    public Meyve (){

    }
    public String getAd() {
        return ad;
    }

    public int getResim() {
        return resim;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }


}
