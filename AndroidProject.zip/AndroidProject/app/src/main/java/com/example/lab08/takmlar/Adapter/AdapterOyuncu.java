package com.example.lab08.takmlar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.takmlar.Model.Oyuncu;
import com.example.lab08.takmlar.R;


import java.util.ArrayList;

public class AdapterOyuncu extends BaseAdapter {
    private ArrayList<Oyuncu> oyuncular;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterOyuncu() {
    }

    public AdapterOyuncu(ArrayList<Oyuncu> oyuncular, Context context) {
        this.oyuncular = oyuncular;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return oyuncular.size();
    }

    @Override
    public Oyuncu getItem(int position) {
        return oyuncular.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=layoutInflater.inflate(R.layout.oyuncu_satirgoruntusu,null);
        TextView tvoyuncuAdSoyad,tvYas,tvFormaNo;
        ImageView ivoyuncu= v.findViewById(R.id.ivoyuncu);
        tvoyuncuAdSoyad=v.findViewById(R.id.tvoyuncuAdSoyad);
        tvYas=v.findViewById(R.id.tvYas);
        tvFormaNo=v.findViewById(R.id.tvFormaNo);

        int resim= v.getResources().getIdentifier(
                oyuncular.get(position).getFoto(),
                "drawable",context.getPackageName()
        );
        ivoyuncu.setImageResource(resim);
        return v;

    }
}
