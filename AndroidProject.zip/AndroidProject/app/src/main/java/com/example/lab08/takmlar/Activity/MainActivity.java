package com.example.lab08.takmlar.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.lab08.takmlar.Adapter.AdapterTakım;
import com.example.lab08.takmlar.Model.Takım;
import com.example.lab08.takmlar.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Takım> takımlar=new ArrayList<>();
    AdapterTakım adapterTakım;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=findViewById(R.id.listview);
        takımlar.add(new Takım("Beşiktaş",R.drawable.bjk));
        takımlar.add(new Takım("Galatasaray",R.drawable.galatsaray));
        takımlar.add(new Takım("Fenerbahçe",R.drawable.fener));

        adapterTakım=new AdapterTakım(takımlar,getApplicationContext());
        listView.setAdapter(adapterTakım);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        "Tıklanan Takım="+takımlar.get(position).getName(),
                        Toast.LENGTH_LONG
                ).show();

              startActivity(new Intent(getApplicationContext(),Oyuncular.class).putExtra("takım_adı",takımlar.
                      get(position).getName())
              );

            }
        });




    }
}
