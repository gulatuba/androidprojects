package com.example.lab08.takmlar.Model;

public class Takım {

    private String name;
    private int image;

    public String getName() {
        return name;
    }

    public int getImage() {
        return image;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public Takım(String name, int image) {
        this.name = name;

        this.image = image;
}

    }
