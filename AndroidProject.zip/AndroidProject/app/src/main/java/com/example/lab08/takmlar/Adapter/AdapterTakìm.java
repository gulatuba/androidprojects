package com.example.lab08.takmlar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.takmlar.Model.Takım;
import com.example.lab08.takmlar.R;

import java.util.ArrayList;

public class AdapterTakım extends BaseAdapter {
    private ArrayList<Takım> takımlar;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterTakım() {
    }
    public AdapterTakım(ArrayList<Takım> takımlar,Context context){

        this.context=context;
        this.takımlar=takımlar;
        this.layoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return takımlar.size();
    }

    @Override
    public Takım getItem(int position) {

        return takımlar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=layoutInflater.inflate(R.layout.takim_satirgoruntusu,null);
        ImageView image1=v.findViewById(R.id.image1);
        TextView textView1=v.findViewById(R.id.textView1);

        textView1.setText(takımlar.get(position).getName());
        image1.setImageResource(takımlar.get(position).getImage());

        return v;
    }
}
