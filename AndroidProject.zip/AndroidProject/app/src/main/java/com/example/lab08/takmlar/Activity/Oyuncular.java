package com.example.lab08.takmlar.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.lab08.takmlar.Adapter.AdapterOyuncu;
import com.example.lab08.takmlar.Model.Oyuncu;
import com.example.lab08.takmlar.R;

import java.util.ArrayList;

public class Oyuncular extends AppCompatActivity {

    ListView listView;
    AdapterOyuncu adapterOyuncu;
    ArrayList<Oyuncu> oyuncular =new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyuncular);

        String takim=getIntent().getStringExtra("takim_adi");
        setTitle(takim);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//toolbar da geri butonu ekleme

        listView=findViewById(R.id.oyuncu);
        //  private int id;
        //    private String adSoyad;
        //    private String foto;
        //    private int yas;
        //    private int formaNo
        if("Galatasaray".equals(takim))
        {
            //int id, String adSoyad, String foto, int yas, int formaNo
           oyuncular.add(new Oyuncu(1,"semih taş","galata1",33,1));
           oyuncular.add(new Oyuncu(2,"ahmet kaya","galata2",34,2));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {//menu ıtemlarını tıklama olayı
        if(item.getItemId()==android.R.id.home)
        {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
